package com.pronabc.finanz.service;

public class StudentService {
}
