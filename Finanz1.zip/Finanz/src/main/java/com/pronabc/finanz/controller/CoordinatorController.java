package com.pronabc.finanz.controller;

public class CoordinatorController {
}
