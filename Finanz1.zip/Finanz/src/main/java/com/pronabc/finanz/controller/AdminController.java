package com.pronabc.finanz.controller;

public class AdminController {

}
