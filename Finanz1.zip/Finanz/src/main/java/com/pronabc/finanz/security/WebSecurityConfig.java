package com.pronabc.finanz.security;

public class WebSecurityConfig {
}
