package com.pronabc.finanz.repository;

public class UserRepository {
}
