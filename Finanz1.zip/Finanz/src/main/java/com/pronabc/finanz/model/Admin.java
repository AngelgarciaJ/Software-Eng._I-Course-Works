package com.pronabc.finanz.model;

public class Admin {
}
