package com.pronabc.finanz.model;

public class User {
}
