package com.pronabc.finanz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinanzApplicationTests {

    @Test
    void contextLoads() {
    }

}
